Dataset Fruit (Uma parte do Grocery Store Dataset)

	Total de 1.140 imagens (276 apples, 41 avocados, 45 bananas, 46 kiwis, 42 lemons, 31 limes, 32 mangos, 154 melons, 36 nectarines, 57 oranges, 21 papayas, 28 passion-fruits, 37 peachs, 116 pears, 26 pineapples, 22 plums, 26 pomegranates, 34 red-grapefruits, 70 satsumas)

Classes
	
	C01 = Apple
	C02 = Avocado
	C03 = Banana
	C04 = Kiwi
	C05 = Lemon
	C06 = Lime
	C07 = Mango
	C08 = Melon
	C09 = Nectarine
	C10 = Orange
	C11 = Papaya
	C12 = Passion-Fruit
	C13 = Peach
	C14 = Pear
	C15 = Pineapple
	C16 = Plum
	C17 = Pomegranate
	C18 = Red-Grapefruit
	C19 = Satsumas

Fonte: https://github.com/marcusklasson/GroceryStoreDataset